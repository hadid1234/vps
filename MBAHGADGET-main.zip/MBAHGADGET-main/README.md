# RDP Windows Gratis 6 Jam

Buat RDP Windows Ram 7GB 2 Core Cpu Dengan Github:

+ Tekan Tombol Fork untuk membuat RDP (Bagi Pengguna Android/HP Disilahkan Pake Mode Desktop).
+ kunjungi https://dashboard.ngrok.com untuk mendapatkan NGROK_AUTH_TOKEN
+ Di Dalam Repo ini Pergi ke Settings> Secrets> New repository secret
+ isi Nama: Masukan NGROK_AUTH_TOKEN
+ isi Value: Kunjungi https://dashboard.ngrok.com/auth/your-authtoken Copy Dan Paste di dalam value
+ Tekan Add secret
+ Pergi Ke Action> CI> Run workflow
+ Refresh Web dan masuk ke CI> build
+ Tekan Tombol panah menghadap ke bawah "RDP INFO LOGIN" Untuk Mendapatkan IP, User, Password.
